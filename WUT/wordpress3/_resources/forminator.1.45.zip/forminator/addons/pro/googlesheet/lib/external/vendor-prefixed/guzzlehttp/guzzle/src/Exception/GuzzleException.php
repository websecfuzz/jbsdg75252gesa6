<?php

namespace ForminatorGoogleAddon\GuzzleHttp\Exception;

use ForminatorGoogleAddon\Psr\Http\Client\ClientExceptionInterface;
interface GuzzleException extends ClientExceptionInterface
{
}
