<?php

namespace ForminatorGoogleAddon\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
