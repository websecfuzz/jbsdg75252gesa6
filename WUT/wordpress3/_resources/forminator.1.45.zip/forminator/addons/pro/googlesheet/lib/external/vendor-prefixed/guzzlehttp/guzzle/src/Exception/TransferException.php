<?php

namespace ForminatorGoogleAddon\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
