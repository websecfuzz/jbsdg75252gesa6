<?php

namespace ForminatorGoogleAddon\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
