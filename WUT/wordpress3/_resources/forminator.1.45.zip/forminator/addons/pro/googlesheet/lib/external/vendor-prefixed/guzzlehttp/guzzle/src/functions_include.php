<?php

namespace ForminatorGoogleAddon;

// Don't redefine the functions if included multiple times.
if (!\function_exists('ForminatorGoogleAddon\\GuzzleHttp\\describe_type')) {
    require __DIR__ . '/functions.php';
}
